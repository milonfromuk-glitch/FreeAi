@file:OptIn(ExperimentalMaterial3Api::class)

package com.freeai.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Color(0xFF0F1115), surface = Color(0xFF171A21),
                primary = Color(0xFF7C9CFF), onPrimary = Color.Black,
                surfaceVariant = Color(0xFF232733))) { App(store) }
        }
    }
}

fun encodeImage(ctx: Context, uri: Uri): String? = try {
    val bmp = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) }
    val s = 1024f / maxOf(bmp.width, bmp.height)
    val b = if (s < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true) else bmp
    val o = ByteArrayOutputStream()
    b.compress(Bitmap.CompressFormat.JPEG, 80, o)
    Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
} catch (e: Exception) { null }

fun friendly(e: Exception): String = when {
    e is ApiError && e.code in listOf(400, 401, 403) -> "Your API key doesn't seem to work. Open the menu (top left) and tap \"API key\" to check it."
    e is ApiError && e.code == 429 -> "You've used the free limit for now. Wait a minute and try again, or pick another model at the top."
    e is ApiError && e.code == 404 -> "This model isn't available. Pick a different one at the top."
    e is UnknownHostException || e is ConnectException -> "No internet. Check your connection and try again."
    e is SocketTimeoutException -> "That took too long. Please try again."
    else -> "Something went wrong. Please try again."
}

@Composable
fun App(store: Store) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val listState = rememberLazyListState()

    var chats by remember { mutableStateOf(store.loadChats()) }
    var currentId by remember { mutableStateOf(chats.firstOrNull()?.id ?: System.currentTimeMillis().toString()) }
    var model by remember { mutableStateOf(store.model) }
    var input by remember { mutableStateOf("") }
    var image by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showKey by remember { mutableStateOf(store.apiKey.isBlank()) }
    var menuOpen by remember { mutableStateOf(false) }

    val current = chats.find { it.id == currentId } ?: Chat(currentId, "New chat", emptyList())

    fun save(c: Chat) {
        chats = listOf(c) + chats.filter { it.id != c.id }
        store.saveChats(chats)
    }
    fun newChat() { currentId = System.currentTimeMillis().toString(); error = null; input = ""; image = null }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) scope.launch { image = withContext(Dispatchers.IO) { encodeImage(ctx, uri) } }
    }

    fun send() {
        val text = input.trim()
        if ((text.isEmpty() && image == null) || loading) return
        if (store.apiKey.isBlank()) { showKey = true; return }
        val updated = current.copy(
            title = if (current.msgs.isEmpty()) text.ifBlank { "Photo" }.take(30) else current.title,
            msgs = current.msgs + Msg("user", text, image, image != null))
        save(updated); input = ""; image = null; loading = true; error = null
        scope.launch {
            try {
                val reply = withContext(Dispatchers.IO) { Gemini.ask(store.apiKey, model, updated.msgs) }
                save(updated.copy(msgs = updated.msgs + Msg("model", reply)))
            } catch (e: Exception) { error = friendly(e) }
            loading = false
        }
    }

    LaunchedEffect(current.msgs.size, loading, error) { listState.animateScrollToItem(current.msgs.size + 1) }

    ModalNavigationDrawer(drawerState = drawer, drawerContent = {
        ModalDrawerSheet {
            Text("FreeAI", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp))
            Button(onClick = { newChat(); scope.launch { drawer.close() } },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) { Text("+ New chat") }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(chats) { c ->
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { currentId = c.id; error = null; scope.launch { drawer.close() } },
                            modifier = Modifier.weight(1f)) {
                            Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth())
                        }
                        IconButton(onClick = {
                            chats = chats.filter { it.id != c.id }; store.saveChats(chats)
                            if (c.id == currentId) newChat()
                        }) { Icon(Icons.Default.Delete, "Delete chat") }
                    }
                }
            }
            TextButton(onClick = { showKey = true; scope.launch { drawer.close() } },
                modifier = Modifier.padding(8.dp)) { Text("API key") }
        }
    }) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background, topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                navigationIcon = { IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, "Menu") } },
                title = {
                    Box {
                        TextButton(onClick = { menuOpen = true }) { Text("$model ▾") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            Gemini.models.forEach { m ->
                                DropdownMenuItem(text = { Text(m) }, onClick = { model = m; store.model = m; menuOpen = false })
                            }
                        }
                    }
                },
                actions = { IconButton(onClick = { newChat() }) { Icon(Icons.Default.Add, "New chat") } })
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (current.msgs.isEmpty()) {
                        Text("How can I help you today?", style = MaterialTheme.typography.titleMedium,
                            color = Color.Gray, modifier = Modifier.align(Alignment.Center))
                    }
                    LazyColumn(state = listState, contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(current.msgs) { m ->
                            val mine = m.role == "user"
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                                Box(Modifier.widthIn(max = 320.dp).clip(RoundedCornerShape(18.dp))
                                    .background(if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(12.dp)) {
                                    Text((if (m.hadImage) "📷 Photo\n" else "") + m.text,
                                        color = if (mine) Color.Black else Color.White)
                                }
                                if (!mine) TextButton(onClick = { clipboard.setText(AnnotatedString(m.text)) }) { Text("Copy") }
                            }
                        }
                        item {
                            if (loading) Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp)); Text("Thinking…", color = Color.Gray)
                            } else Spacer(Modifier.height(1.dp))
                        }
                        item {
                            error?.let {
                                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF3A1E1E)).padding(12.dp)) { Text(it, color = Color(0xFFFFB4B4)) }
                            } ?: Spacer(Modifier.height(1.dp))
                        }
                    }
                }
                if (image != null) {
                    AssistChip(onClick = { image = null }, label = { Text("📷 Photo attached  ✕") },
                        modifier = Modifier.padding(horizontal = 12.dp))
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("📎") }
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Message FreeAI") }, maxLines = 5, shape = RoundedCornerShape(24.dp))
                    IconButton(onClick = { send() }, enabled = !loading) { Icon(Icons.AutoMirrored.Filled.Send, "Send") }
                }
            }
        }
    }

    if (showKey) {
        var key by remember { mutableStateOf(store.apiKey) }
        AlertDialog(onDismissRequest = { showKey = false },
            title = { Text("Paste your free API key") },
            text = {
                Column {
                    Text("Get a free key at aistudio.google.com/apikey and paste it here. It stays only on this phone.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = key, onValueChange = { key = it }, singleLine = true, placeholder = { Text("API key") })
                }
            },
            confirmButton = { TextButton(onClick = { store.apiKey = key; showKey = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showKey = false }) { Text("Cancel") } })
    }
}
