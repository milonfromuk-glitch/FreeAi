package com.freeai.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ApiError(val code: Int) : Exception()

// The AI service: Google Gemini (has a free tier and understands images).
object Gemini {
    // If a model stops working one day, change the names in this list.
    val models = listOf("gemini-2.5-flash", "gemini-2.5-flash-lite")

    fun ask(key: String, model: String, history: List<Msg>): String {
        val contents = JSONArray()
        for (m in history) {
            val parts = JSONArray()
            if (m.imageB64 != null) {
                parts.put(JSONObject().put("inline_data",
                    JSONObject().put("mime_type", "image/jpeg").put("data", m.imageB64)))
            }
            if (m.text.isNotBlank()) parts.put(JSONObject().put("text", m.text))
            if (parts.length() == 0) parts.put(JSONObject().put("text", "(photo)"))
            contents.put(JSONObject().put("role", if (m.role == "user") "user" else "model").put("parts", parts))
        }
        val body = JSONObject().put("contents", contents).toString()
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.doOutput = true
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        if (code !in 200..299) throw ApiError(code)
        val text = c.inputStream.bufferedReader().readText()
        val cands = JSONObject(text).optJSONArray("candidates")
        val parts = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return "Sorry, I couldn't answer that one. Try asking in a different way."
        return (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
    }
}
