package com.freeai.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Msg(val role: String, val text: String, val imageB64: String? = null, val hadImage: Boolean = false)
data class Chat(val id: String, val title: String, val msgs: List<Msg>)

// Saves your key, chosen model and chat history privately on this phone only.
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("freeai", Context.MODE_PRIVATE)

    var apiKey: String
        get() = p.getString("key", "") ?: ""
        set(v) { p.edit().putString("key", v.trim()).apply() }

    var model: String
        get() = p.getString("model", Gemini.models[0]) ?: Gemini.models[0]
        set(v) { p.edit().putString("model", v).apply() }

    fun loadChats(): List<Chat> = try {
        val arr = JSONArray(p.getString("chats", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val m = o.getJSONArray("msgs")
            Chat(o.getString("id"), o.getString("title"), (0 until m.length()).map { j ->
                val x = m.getJSONObject(j)
                Msg(x.getString("role"), x.getString("text"), null, x.optBoolean("img"))
            })
        }
    } catch (e: Exception) { emptyList() }

    fun saveChats(list: List<Chat>) {
        val arr = JSONArray()
        list.forEach { c ->
            val ms = JSONArray()
            c.msgs.forEach { ms.put(JSONObject().put("role", it.role).put("text", it.text).put("img", it.hadImage)) }
            arr.put(JSONObject().put("id", c.id).put("title", c.title).put("msgs", ms))
        }
        p.edit().putString("chats", arr.toString()).apply()
    }
}
